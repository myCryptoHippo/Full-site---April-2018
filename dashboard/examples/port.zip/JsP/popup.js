$(document).ready(function(){
	alert("a");
	$("#back").hide();
	$("#panel").hide();
}
function popup(){
	
}