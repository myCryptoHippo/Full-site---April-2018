<?php
/* Displays user information and some useful messages */
session_start();

// Check if user is logged in using the session variable
if ( $_SESSION['logged_in'] != 1 ) {
  header("location: ../../login.php");    
}
if ( $_SESSION['active'] != 1 ) {
  $_SESSION['message'] = "Account not activated!";
  header("location: ../../error.php");    
}
else {
    // Makes it easier to read
    $id = $_SESSION['id'];
    $username = $_SESSION['username'];
    $email = $_SESSION['email'];
    $active = $_SESSION['active'];
}
require '../../net_worth.php';

?>

<!DOCTYPE html>
<html>
    
    <head>
        <link rel="stylesheet" href="CSS/topNavBar.css">
        <link rel="stylesheet" href="CSS/main.css">
        <link rel="stylesheet" href="CSS/LeftNavBar.css">
          <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">

	   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
        
	   <script src="jquery-3.2.1.min.js"></script> 
        
		
    </head>
<?php 
if ($_SERVER['REQUEST_METHOD'] == 'POST') 
{
    if (isset($_POST['buy'])) { //user logging in
        require 'buy.php';

    }
    
    elseif (isset($_POST['sell'])) { //user registering
        
        require 'sell.php';

    }
}
?>
    <body>
    
        <div class="topNavBar">
            <img src="Assets/Logo.png" id="logo">
            <div id="profile">
                <img src="Assets/profile.png" id="profilePic">
                <div style="name">
                    <?php echo $username ?>
                </div>
            </div>
 <div id="logOutButton">
                    <a href="../../logout.php" style="color: black;">Logout</a>
            </div>        </div>
        

        <!--Left Navigation Pane -->
        <div class="leftNavBar">
            <div id="selectingBlock"></div>
            <div id="leftNavBarspacer_Top"></div>
            <ul id="leftNavChoices">
                <li id="li_leftNavChoices"><a href='dashboard.php'>Dashboard</a></li>
                <li id="li_leftNavChoices" style="font-weight: bolder;"><a href=#>My Portfolio</a></li>
                <li id="li_leftNavChoices"><a href=#>Resources</a></li>
            </ul>


            <div id="leftNavFooter">
                <a href=# id="leftNavAboutUs">About us</a>
                <div>
                    <a href="https://medium.com/mycryptohippo/welcome-to-behindtheproduct-571825990f29"><img id="aboutUsFooterIcons" src="pictures/medium_icon_20.png" alt="myCryptoHippo Medium Icon"></a>
                    <a href="https://instagram.com/myCryptoHippo"><img id="aboutUsFooterIcons" src="pictures/instagram_icon_20.png" alt="myCryptoHippo Instagram Icon"></a>
                    <a href="https://www.facebook.com/mycryptohippo/?ref=br_rs"><img id="aboutUsFooterIcons" src="pictures/facebook_icon_20.png" alt="myCryptoHippo Facebook Icon"></a>
                    <a href="https://twitter.com/myCryptoHippo"><img id="aboutUsFooterIcons" src="pictures/Twitter_icon_20.png" alt="myCryptoHippo Twitter Icon"></a>
                </div>
            </div> <!--class "leftNaveFooter" end-->
        </div>

        
        <div id="mainPanel">

            <div id="w1">
                <div id="title">Your Portfolio</div>
                <div id="des">You started with $10,000 but you have now grown that to <a id="curValue" style="color: #46a049">$10,127,93</a> ! You are doing great.</div>
                <div id="box1">
                    <div id="subT1">Your Net Worth</div>
                    <p id="netWorth">$10,000.93 <a id="usd">USD</a></p>  
                </div>

                <div id="box2">
                    <div id="subT1">Cash</div>
                    <p class="text1" id="cash">$5,000.93 </p>
                </div>

                <div id="box2">
                    <div id="subT1">Coins</div>
                    <p class="text1" id="coins">$5,000.00</p>
                </div>
                
                <div id="box4">
                    <div id="text2"></div>
                    
                    
                    <div id="header">
                        <div id="he1">
                            Coin
                        </div>
                        <div id="he2">
                            Amount
                        </div>
                        <div id="he3">
                            Worth (USD)
                        </div>
                        <div id="he4">
                            (+/-)
                        </div>
                    </div>

                    <div id="row">
                        <div id="ro1"> 
                            <div id="ETH">ETH</div>
                        </div>
                        <div id="ro2">
                            1.137
                        </div>
                        <div id="ro3">
                            <a id="val">$959.1613</a>
                            <a id="percIn">
                            +4.58%</a>
                        </div>
                    </div>
                    
                    <div id="divLine"></div>
                    <div id="row">
                        <div id="ro1"> 
                            <div id="XRP">XRP</div>
                        </div>
                        <div id="ro2">
                            892.71
                        </div>
                        <div id="ro3">
                            <a id="val">$901.6392</a>
                            <a id="percIn" >
                            +6.46%</a>
                        </div>
                    </div>

                    <div id="divLine"></div>
                    <div id="row">
                        <div id="ro1"> 
                            <div id="BTC">BTC</div>
                        </div>
                        <div id="ro2">
                            0.082
                        </div>
                        <div id="ro3">
                            <a id="val">$15,000.00</a>
                            <a id="percIn" >
                            +1.70%</a>
                        </div>
                    </div>

                    <div id="divLine"></div>
                    <div id="row">
                        <div id="ro1"> 
                            <div id="LTC">LTC</div>
                        </div>
                        <div id="ro2">
                            4.254
                        </div>
                        <div id="ro3">
                            <a id="val">$898.7848</a>
                            <a id="percIn" >
                            +1.52%</a>
                        </div>
                    </div>

                    <div id="divLine"></div>
                    <div id="row">
                        <div id="ro1"> 
                            <div id="BCH">BCH</div>
                        </div>
                        <div id="ro2">
                            0.664
                        </div>
                        <div id="ro3">
                            <a id="val">$861.7911</a>
                            <a id="percDe" >
                            -0.98%</a>
                        </div>
                    </div>

                    <div id="divLine"></div>
                    <div id="row">
                        <div id="ro1"> 
                            <div id="ADA">ADA</div>
                        </div>
                        <div id="ro2">
                            2496.62
                        </div>
                        <div id="ro3">
                            <a id="val">$898.7848</a>
                            <a id="percIn" >
                            +1.52%</a>
                        </div>
                    </div>
                </div>
            </div>
            


            <div id="w2">
                <div id="title">Buy Coins</div>
                <div id="w2_des">There's only one way to become the richest hippo. Buy more coins.</div>

                <div id="header">
                        <div id="w2_he1">
                            Coin
                        </div>
                        <div id="w2_he2">
                            Price (USD)
                        </div>
                        <div id="w2_he3">
                            Change (24h)
                        </div>
                        <div id="w2_he4">
                            Buy/Sell
                        </div>
                    </div>
                    <div id="divLine1"></div>

                    <div id="w2_row">
                        <div id="w2_ro1"> 
                            <div id="ETH1">ETH</div>
                        </div>
                        <div id="w2_ro2">
                            $843.13
                        </div>
                        <div id="w2_ro3">
                            <a id="percIn"> +4.58% </a>
                        </div>
                        <div id="w2_ro4">
                            <button class="buy" id="ethereum">Buy</button>
                        </div>
                        <div id="w2_ro5">
                            <button class="sell" id="ethereum">Sell</button>
                        </div>
                    </div>

                    <div id="divLine"></div>
                    <div id="w2_row">
                        <div id="w2_ro1"> 
                            <div id="XRP1">XRP</div>
                        </div>
                        <div id="w2_ro2">
                            $1.01
                        </div>
                        <div id="w2_ro3">
                            <a id="percIn"> +6.46% </a>
                        </div>
                        <div id="w2_ro4">
                            <button class="buy" id="ethereum">Buy</button>
                        </div>
                        <div id="w2_ro5">
                            <button class="sell" id="ethereum">Sell</button>
                        </div>
                    </div>

                    <div id="divLine"></div>
                    <div id="w2_row">
                        <div id="w2_ro1"> 
                            <div id="BTC1">BTC</div>
                        </div>
                        <div id="w2_ro2">
                            $10,580.20
                        </div>
                        <div id="w2_ro3">
                            <a id="percIn"> +1.70% </a>
                        </div>
                        <div id="w2_ro4">
                            <button class="buy" id="ethereum">Buy</button>
                        </div>
                        <div id="w2_ro5">
                            <button class="sell" id="ethereum">Sell</button>
                        </div>
                    </div>

                    <div id="divLine"></div>
                    <div id="w2_row">
                        <div id="w2_ro1"> 
                            <div id="LTC1">LTC</div>
                        </div>
                        <div id="w2_ro2">
                            $211.24
                        </div>
                        <div id="w2_ro3">
                            <a id="percIn"> +1.52% </a>
                        </div>
                        <div id="w2_ro4">
                            <button class="buy" id="ethereum">Buy</button>
                        </div>
                        <div id="w2_ro5">
                            <button class="sell" id="ethereum">Sell</button>
                        </div>
                    </div>

                    <div id="divLine"></div>
                    <div id="w2_row">
                        <div id="w2_ro1"> 
                            <div id="BCH1">BCH</div>
                        </div>
                        <div id="w2_ro2">
                            $1,296.78
                        </div>
                        <div id="w2_ro3">
                            <a id="percDe"> -0.98% </a>
                            
                        </div>
                        <div id="w2_ro4">
                            <button class="buy" id="ethereum">Buy</button>
                        </div>
                        <div id="w2_ro5">
                            <button class="sell" id="ethereum">Sell</button>
                        </div>
                    </div>

                    <div id="divLine"></div>
                    <div id="w2_row">
                        <div id="w2_ro1"> 
                            <div id="ADA1">ADA</div>
                        </div>
                        <div id="w2_ro2">
                            $0.36
                        </div>
                        <div id="w2_ro3">
                            <a id="percIn"> +1.52% </a>
                        </div>
                        <div id="w2_ro4">
                            <button class="buy" id="ethereum">Buy</button>
                        </div>
                        <div id="w2_ro5">
                            <button class="sell" id="ethereum">Sell</button>
                        </div>
                    </div>       
            </div>
            <div id="w3">
                <div id="title">Transaction History (COMING SOON)</div>
                <div id="w2_des">View what you bought and sold.</div>

                <div id="header">
                        <div id="w3_he1">
                            Action
                        </div>
                        <div id="w3_he2">
                            Date
                        </div>
                        <div id="w3_he3">
                            Coin
                        </div>
                        <div id="w3_he4">
                            Amount
                        </div>
                        <div id="w3_he5">
                            Worth (USD)
                        </div>
                </div>

                    <div id="w3_row">
                        <div id="w3_ro1"> 
                            BOUGHT
                        </div>
                        <div id="w3_ro2">
                            Dec. 3, 2017
                        </div>
                        <div id="w3_ro3">
                            12:30 PM
                        </div>
                        <div id="w3_ro4">
                            BTC
                        </div>
                        <div id="w3_ro5">
                            $10000
                        </div>
                        <div id="w3_ro6">
                            1.12
                        </div>
                    </div>

                    <div id="divLine"></div>
            </div>
        </div>
        
                
        <!--popup-->
        
        
        <div id="buyd" class="popup">
            <p id="pTitle">Buy Coin</p>
            <br><br>
            <form action="portfolio.php">
                  Buy
                  <input type="text" name="val" placeholder="$0.00" id="txtField">
                     Bitcoin for 
                  <input type="text" name="coin" placeholder="$0.00" id="txtField">
                  <br><br>
                  <input type="submit" name="buy" id="submitButton">
             </form>
        </div>
        
        <div id="selld" class="popup">
            <p id="pTitle">Sell Coin</p>
            <br><br>
            <form action="portfolio.php">
                  Sell
                  <input type="text" name="val" placeholder="$0.00" id="txtField">
                     Bitcoin for 
                  <input type="text" name="coin" placeholder="$0.00" id="txtField">
                  <br><br>
                  <input type="submit" name="sell" id="submitButton">
             </form>
        </div>
         <script>
            var idClicked = 0; 
             //id is automatically initialized after the popup appears as the name of the coin so feel free to use it when proessing transaction
             
            //POPUP
            
             //Initialize dialog
            $("#buyd").dialog({
                width: 500,
                autoOpen: false,
                modal: true, 
                dialogClass: "no-close",
                buttons: {
                    Close: function () {
                        $(this).dialog("close");
                    },
                },
                open: function (e, ui) {
                    $(this).parent().find(".ui-dialog-buttonpane .ui-button")
                        .addClass("pb");
                }
            });

            //Open it when #opener is clicked
            $(".buy").click(function () {
                idClicked = this.id;
                $("#buyd").dialog("open");
                $("#ui-dialog-title-dialog").hide();
            })
             
             
             //Initialize dialog
            $("#selld").dialog({
                width: 500,
                autoOpen: false,
                modal: true, 
                dialogClass: "no-close",
                buttons: {
                    Close: function () {
                        $(this).dialog("close");
                    },
                },
                open: function (e, ui) {
                    $(this).parent().find(".ui-dialog-buttonpane .ui-button")
                        .addClass("pb");
                }
            });
            //Open it when #opener is clicked
            $(".sell").click(function () {
                idClicked = this.id;
                $("#selld").dialog("open");
                $("#ui-dialog-title-dialog").hide();
            })

        </script>
        
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
        
    </body>
            <script>
                $.get("https://api.coinmarketcap.com/v1/ticker/", function(data,status) {
                    for (var i = 0; i < data.length - 1; i++) {
                        if (data[i].id == "bitcoin") {
                            $("#BTC_Price").html(data[i].price_usd)
                            $("#BTC_Change").html((data[i].percent_change_24h).concat("%"))
                             $("#change_margin").html(Math.round(parseFloat(data[i].price_usd) * data[i].percent_change_24h/100 * 10000)/10000)           
                        }
                        if (data[i].id == "ethereum") {
                            $("#ETH_Price").html(data[i].price_usd)
                            $("#ETH_Change").html((data[i].percent_change_24h).concat("%"))
                             $("#ETH_change_margin").html(Math.round(parseFloat(data[i].price_usd) * data[i].percent_change_24h/100 * 10000)/10000)           
                        }
                        if (data[i].id == "litecoin") {
                            $("#LTC_Price").html(data[i].price_usd)
                            $("#LTC_Change").html((data[i].percent_change_24h).concat("%"))
                             $("#LTC_change_margin").html(Math.round(parseFloat(data[i].price_usd) * data[i].percent_change_24h/100 * 10000)/10000)           
                        }
                        if (data[i].id == "iota") {
                            $("#MIOTA_Price").html(data[i].price_usd)
                            $("#MIOTA_Change").html((data[i].percent_change_24h).concat("%"))
                             $("#MIOTA_change_margin").html(Math.round(parseFloat(data[i].price_usd) * data[i].percent_change_24h/100 * 10000)/10000)           
                        }
                        if (data[i].id == "bitcoin-cash") {
                            $("#BCH_Price").html(data[i].price_usd)
                            $("#BCH_Change").html((data[i].percent_change_24h).concat("%"))
                             $("#BCH_change_margin").html(Math.round(parseFloat(data[i].price_usd) * data[i].percent_change_24h/100 * 10000)/10000)           
                        }
                        if (data[i].id == "ripple") {
                            $("#XRP_Price").html(data[i].price_usd)
                            $("#XRP_Change").html((data[i].percent_change_24h).concat("%"))
                             $("#XRP_change_margin").html(Math.round(parseFloat(data[i].price_usd) * data[i].percent_change_24h/100 * 10000)/10000)           
                        }
                        if (data[i].id == "cardano") {
                            $("#ADA_Price").html(data[i].price_usd)
                            $("#ADA_Change").html((data[i].percent_change_24h).concat("%"))
                             $("#ADA_change_margin").html(Math.round(parseFloat(data[i].price_usd) * data[i].percent_change_24h/100 * 10000)/10000)           
                        }
                        if (data[i].id == "stellar") {
                            $("#XLM_Price").html(data[i].price_usd)
                            $("#XLM_Change").html((data[i].percent_change_24h).concat("%"))
                             $("#XLM_change_margin").html(Math.round(parseFloat(data[i].price_usd) * data[i].percent_change_24h/100 * 10000)/10000)           
                        }
                        if (data[i].id == "eos") {
                            $("#EOS_Price").html(data[i].price_usd)
                            $("#EOS_Change").html((data[i].percent_change_24h).concat("%"))
                             $("#EOS_change_margin").html(Math.round(parseFloat(data[i].price_usd) * data[i].percent_change_24h/100 * 10000)/10000)           
                        }
                        if (data[i].id == "neo") {
                            $("#NEO_Price").html(data[i].price_usd)
                            $("#NEO_Change").html((data[i].percent_change_24h).concat("%"))
                             $("#NEO_change_margin").html(Math.round(parseFloat(data[i].price_usd) * data[i].percent_change_24h/100 * 10000)/10000)           
                        }

                    }
                });
            </script>
  <script src='https://ajax.googleapis.com/ajax/libs/jquery/3.0.0/jquery.min.js'></script>

    <script src="js/index.js"></script>

</html>