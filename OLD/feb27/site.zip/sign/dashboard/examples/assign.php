<?php
$coin = $_POST['coin'];
?>