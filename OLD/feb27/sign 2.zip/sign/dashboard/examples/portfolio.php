<?php
/* Displays user information and some useful messages */
session_start();

// Check if user is logged in using the session variable
if ( $_SESSION['logged_in'] != 1 ) {
  header("location: ../../login.php");    
}
else {
    // Makes it easier to read
    $id = $_SESSION['id'];
    $username = $_SESSION['username'];
    $email = $_SESSION['email'];
    $active = $_SESSION['active'];
}
require '../../net_worth.php';

?>

<!DOCTYPE html>
<html>
    
    <head>
        <link rel="stylesheet" href="CSS/topNavBar.css">
        <link rel="stylesheet" href="CSS/main.css">
        <link rel="stylesheet" href="CSS/LeftNavBar.css">
        
	   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
        
	   <script src="jquery-3.2.1.min.js"></script> 
        
		
    </head>
<?php 
if ($_SERVER['REQUEST_METHOD'] == 'POST') 
{
    if (isset($_POST['buy'])) { //user logging in
        require 'buy.php';

    }
    
    elseif (isset($_POST['sell'])) { //user registering
        
        require 'sell.php';

    }
}
?>
    <body>
    
        <div class="topNavBar">
            <img src="Assets/Logo.png" id="logo">
            <div id="profile">
                <img src="Assets/profile.png" id="profilePic">
                <div style="name">
                    <?php echo $username ?>
                </div>
            </div>
            <div id="logOutButton" href="../../logout.php">
                    Logout
            </div>
        </div>
        

        <!--Left Navigation Pane -->
        <div class="leftNavBar">
            <div id="selectingBlock"></div>
            <div id="leftNavBarspacer_Top"></div>
            <ul id="leftNavChoices">
                <li id="li_leftNavChoices"><a href='dashboard.php'>Dashboard</a></li>
                <li id="li_leftNavChoices" style="font-weight: bolder;"><a href=#>My Portfolio</a></li>
                <li id="li_leftNavChoices"><a href=#>Resources</a></li>
                <li id="li_leftNavChoices"><a href=#>Settings</a></li>
            </ul>


            <div id="leftNavFooter">
                <a href=# id="leftNavAboutUs">About us</a>
                <div>
                    <a href="https://medium.com/mycryptohippo/welcome-to-behindtheproduct-571825990f29"><img id="aboutUsFooterIcons" src="pictures/medium_icon_20.png" alt="myCryptoHippo Medium Icon"></a>
                    <a href="https://instagram.com/myCryptoHippo"><img id="aboutUsFooterIcons" src="pictures/instagram_icon_20.png" alt="myCryptoHippo Instagram Icon"></a>
                    <a href="https://www.facebook.com/mycryptohippo/?ref=br_rs"><img id="aboutUsFooterIcons" src="pictures/facebook_icon_20.png" alt="myCryptoHippo Facebook Icon"></a>
                    <a href="https://twitter.com/myCryptoHippo"><img id="aboutUsFooterIcons" src="pictures/Twitter_icon_20.png" alt="myCryptoHippo Twitter Icon"></a>
                </div>
            </div> <!--class "leftNaveFooter" end-->
        </div>

        
        <div id="mainPanel">

            <div id="w1">
                <div id="title">Your Portfolio</div>
                <div id="des">You started with $10,000.00 but you now have <a id="curValue" style="color: aquamarine">$<?php echo $usd ?></a> ! You are doing great.</div>
                <div id="box1">
                    <div id="subT1">Your Net Worth</div>
                    <p id="netWorth">$<?php echo round($net, 2) ?> <a id="usd">USD</a></p>  
                </div>

                <div id="box2">
                    <div id="subT1">Cash</div>
                    <p class="text1" id="cash">$<?php echo $usd ?></p>
                </div>

                <div id="box2">
                    <div id="subT1">Coins</div>
                    <p class="text1" id="coins">$<?php echo $net - $usd ?></p>
                </div>
                
                <div id="box4">
                    <div id="text2">Think the price will dip? Sell your coins.</div>
                    
                    
                    <div id="header">
                        <div id="he1">
                            Coin
                        </div>
                        <div id="he2">
                            Amount
                        </div>
                        <div id="he3">
                            Worth (USD)
                        </div>
                    </div>

                    <div id="row">
                        <div id="ro1"> 
                            BTC
                        </div>
                        <div id="ro2">
                            <?php echo $btc?>
                        </div>
                        <div id="ro3">
                            <div id="BTC_Price"></div>
                        </div>
                    </div>
                    
                    <div id="divLine"></div>
                    <div id="row">
                        <div id="ro1"> 
                            ETC
                        </div>
                        <div id="ro2">
                            <?php echo $eth ?>
                        </div>
                        <div id="ro3">
                            <div id="ETH_Price"></div>
                        </div>
                    </div>

                    <div id="divLine"></div>
                    <div id="row">
                        <div id="ro1"> 
                            LTC
                        </div>
                        <div id="ro2">
                            <?php echo $ltc ?>
                        </div>
                        <div id="ro3">
                            <div id="LTC_Price"></div>
                        </div>
                    </div>

                    <div id="divLine"></div>
                    <div id="row">
                        <div id="ro1"> 
                            BCH
                        </div>
                        <div id="ro2">
                            <?php echo $bch ?>
                        </div>
                        <div id="ro3">
                            <div id="BCH_Price"></div>
                        </div>
                    </div>

                    <div id="divLine"></div>
                    <div id="row">
                        <div id="ro1"> 
                            XRP
                        </div>
                        <div id="ro2">
                            <?php echo $xrp ?>
                        </div>
                        <div id="ro3">
                            <div id="XRP_Price"></div>
                        </div>
                    </div>

                    <div id="divLine"></div>
                    <div id="row">
                        <div id="ro1"> 
                            ADA
                        </div>
                        <div id="ro2">
                            <?php echo $ada ?>
                        </div>
                        <div id="ro3">
                            <div id="ADA_Price"></div>
                        </div>
                    </div>

                    <div id="divLine"></div>
                    <div id="row">
                        <div id="ro1"> 
                            IOT
                        </div>
                        <div id="ro2">
                            <?php echo $iot ?>
                        </div>
                        <div id="ro3">
                            <div id="MIOTA_Price"></div>
                        </div>  
                    </div>

                </div>
            </div>
            


            <div id="w2">
                <div id="title">Buy/Sell Coins</div>
                <div id="w2_des">There's only one way to become the richest hippo. Buy more coins.</div>

                <div id="header">
                        <div id="w2_he1">
                            Coin
                        </div>
                        <div id="w2_he2">
                            Price (USD)
                        </div>
                        <div id="w2_he3">
                            Change (24h)
                        </div>
                        <div id="w2_he4">
                            Buy/Sell
                        </div>
                    </div>
                    <div id="divLine"></div>

                    <div id="w2_row">
                        <div id="w2_ro1"> 
                            BTC
                        </div>
                        <div id="w2_ro2">
                            <?php echo price('BTC') ?>
                        </div>
                        <div id="w2_ro3">
                            <?php echo change('BTC') ?>%
                        </div>
                        <div id="w2_ro4">
                        </div>
                        <div id="w2_ro5">
                            <form action="portfolio.php" method="post">
                                                        <input type="hidden" name="coin" value="BTC"/>
                                                        <input type="hidden" name="value" id="BTC_Price"/>
                                                        <div class="form-group"><input type="text" name="amount" class="form-control" placeholder="0.00 (USD)"></div>
                                                        <button class="btn btn-success" type="submit" name="buy">Buy</button>
                                                        <button class="btn btn-danger" type="submit" name="sell">Sell</button>
                                                </form>
                        </div>

                    </div>

                    <div id="divLine"></div>
                    <div id="w2_row">
                        <div id="w2_ro1"> 
                            ETH
                        </div>
                        <div id="w2_ro2">
                            <?php echo price('ETH') ?>
                        </div>
                        <div id="w2_ro3">
                            <?php echo change('ETH') ?>%
                        </div>
                        <div id="w2_ro4">
                        </div>
                        <div id="w2_ro5">
                            <form action="portfolio.php" method="post">
                                                        <input type="hidden" name="coin" value="ETH"/>
                                                        <input type="hidden" name="value" id="ETH_Price"/>
                                                        <div class="form-group"><input type="text" name="amount" class="form-control" placeholder="0.00 (USD)"></div>
                                                        <button class="btn btn-success" type="submit" name="buy">Buy</button>
                                                        <button class="btn btn-danger" type="submit" name="sell">Sell</button>
                                                </form>
                        </div>
                    </div>

                    <div id="divLine"></div>
                    <div id="w2_row">
                        <div id="w2_ro1"> 
                            LTC
                        </div>
                        <div id="w2_ro2">
                            <?php echo price('LTC') ?>
                        </div>
                        <div id="w2_ro3">
                            <?php echo change('LTC') ?>%
                        </div>
                        <div id="w2_ro4">
                        </div>
                        <div id="w2_ro5">
                            <form action="portfolio.php" method="post">
                                                        <input type="hidden" name="coin" value="LTC"/>
                                                        <input type="hidden" name="value" id="LTC_Price"/>
                                                        <div class="form-group"><input type="text" name="amount" class="form-control" placeholder="0.00 (USD)"></div>
                                                        <button class="btn btn-success" type="submit" name="buy">Buy</button>
                                                        <button class="btn btn-danger" type="submit" name="sell">Sell</button>
                                                </form>
                        </div>
                    </div>

                    <div id="divLine"></div>
                    <div id="w2_row">
                        <div id="w2_ro1"> 
                            BCH
                        </div>
                        <div id="w2_ro2">
                            <?php echo price('BCH') ?>
                        </div>
                        <div id="w2_ro3">
                            <?php echo change('BCH') ?>%
                        </div>
                        <div id="w2_ro4">
                        </div>
                        <div id="w2_ro5">
                            <form action="portfolio.php" method="post">
                                                        <input type="hidden" name="coin" value="BCH"/>
                                                        <input type="hidden" name="value" id="BCH_Price"/>
                                                        <div class="form-group"><input type="text" name="amount" class="form-control" placeholder="0.00 (USD)"></div>
                                                        <button class="btn btn-success" type="submit" name="buy">Buy</button>
                                                        <button class="btn btn-danger" type="submit" name="sell">Sell</button>
                                                </form>
                        </div>
                    </div>

                    <div id="divLine"></div>
                    <div id="w2_row">
                        <div id="w2_ro1"> 
                            XRP
                        </div>
                        <div id="w2_ro2">
                            <?php echo price('XRP') ?>
                        </div>
                        <div id="w2_ro3">
                            <?php echo change('XRP') ?>%
                        </div>
                        <div id="w2_ro4">
                        </div>
                        <div id="w2_ro5">
                            <form action="portfolio.php" method="post">
                                                        <input type="hidden" name="coin" value="XRP"/>
                                                        <input type="hidden" name="value" id="XRP_Price"/>
                                                        <div class="form-group"><input type="text" name="amount" class="form-control" placeholder="0.00 (USD)"></div>
                                                        <button class="btn btn-success" type="submit" name="buy">Buy</button>
                                                        <button class="btn btn-danger" type="submit" name="sell">Sell</button>
                                                </form>
                        </div>
                    </div>

                    <div id="divLine"></div>
                    <div id="w2_row">
                        <div id="w2_ro1"> 
                            ADA
                        </div>
                        <div id="w2_ro2">
                            <?php echo price('ADA') ?>
                        </div>
                        <div id="w2_ro3">
                            <?php echo change('ADA') ?>%
                        </div>
                        <div id="w2_ro4">
                        </div>
                        <div id="w2_ro5">
                            <form action="portfolio.php" method="post">
                                                        <input type="hidden" name="coin" value="ADA"/>
                                                        <input type="hidden" name="value" id="ADA_Price"/>
                                                        <div class="form-group"><input type="text" name="amount" class="form-control" placeholder="0.00 (USD)"></div>
                                                        <button class="btn btn-success" type="submit" name="buy">Buy</button>
                                                        <button class="btn btn-danger" type="submit" name="sell">Sell</button>
                                                </form>
                        </div>
                    </div>
                    <div id="divLine"></div>
                    <div id="w2_row">
                        <div id="w2_ro1"> 
                            IOT
                        </div>
                        <div id="w2_ro2">
                            <?php echo price('MIOTA') ?>
                        </div>
                        <div id="w2_ro3">
                            <?php echo change('MIOTA') ?>%
                        </div>
                        <div id="w2_ro4">
                        </div>
                        <div id="w2_ro5">
                            <form action="portfolio.php" method="post">
                                                        <input type="hidden" name="coin" value="MIOTA"/>
                                                        <input type="hidden" name="value" id="MIOTA_Price"/>
                                                        <div class="form-group"><input type="text" name="amount" class="form-control" placeholder="0.00 (USD)"></div>
                                                        <button class="btn btn-success" type="submit" name="buy">Buy</button>
                                                        <button class="btn btn-danger" type="submit" name="sell">Sell</button>
                                                </form>
                        </div>
                    </div>          
            </div>

            <div id="w3">
                <div id="title">Transaction History (coming soon)</div>
                <div id="w2_des">View what you bought and sold.</div>

                <div id="header">
                        <div id="w3_he1">
                            Action
                        </div>
                        <div id="w3_he2">
                            Date
                        </div>
                        <div id="w3_he3">
                            Coin
                        </div>
                        <div id="w3_he4">
                            Amount
                        </div>
                        <div id="w3_he5">
                            Worth (USD)
                        </div>
                </div>

                    <div id="w3_row">
                        <div id="w3_ro1"> 
                            BOUGHT
                        </div>
                        <div id="w3_ro2">
                            Dec. 3, 2017
                        </div>
                        <div id="w3_ro3">
                            12:30 PM
                        </div>
                        <div id="w3_ro4">
                            BTC
                        </div>
                        <div id="w3_ro5">
                            1.00
                        </div>
                        <div id="w3_ro6">
                            $10000
                        </div>
                    </div>

                    <div id="divLine"></div>
                    <div id="w3_row">
                        <div id="w3_ro1">  
                        </div>
                        <div id="w3_ro2">
                        </div>
                        <div id="w3_ro3">
                        </div>
                        <div id="w3_ro4">
                        </div>
                        <div id="w3_ro5">
                        </div>
                        <div id="w3_ro6">
                        </div>
                    </div>

            </div>
            
        </div>
        
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
        
    </body>
            <script>
                $.get("https://api.coinmarketcap.com/v1/ticker/", function(data,status) {
                    for (var i = 0; i < data.length - 1; i++) {
                        if (data[i].id == "bitcoin") {
                            $("#BTC_Price").html(data[i].price_usd)
                            $("#BTC_Change").html((data[i].percent_change_24h).concat("%"))
                             $("#change_margin").html(Math.round(parseFloat(data[i].price_usd) * data[i].percent_change_24h/100 * 10000)/10000)           
                        }
                        if (data[i].id == "ethereum") {
                            $("#ETH_Price").html(data[i].price_usd)
                            $("#ETH_Change").html((data[i].percent_change_24h).concat("%"))
                             $("#ETH_change_margin").html(Math.round(parseFloat(data[i].price_usd) * data[i].percent_change_24h/100 * 10000)/10000)           
                        }
                        if (data[i].id == "litecoin") {
                            $("#LTC_Price").html(data[i].price_usd)
                            $("#LTC_Change").html((data[i].percent_change_24h).concat("%"))
                             $("#LTC_change_margin").html(Math.round(parseFloat(data[i].price_usd) * data[i].percent_change_24h/100 * 10000)/10000)           
                        }
                        if (data[i].id == "iota") {
                            $("#MIOTA_Price").html(data[i].price_usd)
                            $("#MIOTA_Change").html((data[i].percent_change_24h).concat("%"))
                             $("#MIOTA_change_margin").html(Math.round(parseFloat(data[i].price_usd) * data[i].percent_change_24h/100 * 10000)/10000)           
                        }
                        if (data[i].id == "bitcoin-cash") {
                            $("#BCH_Price").html(data[i].price_usd)
                            $("#BCH_Change").html((data[i].percent_change_24h).concat("%"))
                             $("#BCH_change_margin").html(Math.round(parseFloat(data[i].price_usd) * data[i].percent_change_24h/100 * 10000)/10000)           
                        }
                        if (data[i].id == "ripple") {
                            $("#XRP_Price").html(data[i].price_usd)
                            $("#XRP_Change").html((data[i].percent_change_24h).concat("%"))
                             $("#XRP_change_margin").html(Math.round(parseFloat(data[i].price_usd) * data[i].percent_change_24h/100 * 10000)/10000)           
                        }
                        if (data[i].id == "cardano") {
                            $("#ADA_Price").html(data[i].price_usd)
                            $("#ADA_Change").html((data[i].percent_change_24h).concat("%"))
                             $("#ADA_change_margin").html(Math.round(parseFloat(data[i].price_usd) * data[i].percent_change_24h/100 * 10000)/10000)           
                        }
                        if (data[i].id == "stellar") {
                            $("#XLM_Price").html(data[i].price_usd)
                            $("#XLM_Change").html((data[i].percent_change_24h).concat("%"))
                             $("#XLM_change_margin").html(Math.round(parseFloat(data[i].price_usd) * data[i].percent_change_24h/100 * 10000)/10000)           
                        }
                        if (data[i].id == "eos") {
                            $("#EOS_Price").html(data[i].price_usd)
                            $("#EOS_Change").html((data[i].percent_change_24h).concat("%"))
                             $("#EOS_change_margin").html(Math.round(parseFloat(data[i].price_usd) * data[i].percent_change_24h/100 * 10000)/10000)           
                        }
                        if (data[i].id == "neo") {
                            $("#NEO_Price").html(data[i].price_usd)
                            $("#NEO_Change").html((data[i].percent_change_24h).concat("%"))
                             $("#NEO_change_margin").html(Math.round(parseFloat(data[i].price_usd) * data[i].percent_change_24h/100 * 10000)/10000)           
                        }

                    }
                });
            </script>
</html>